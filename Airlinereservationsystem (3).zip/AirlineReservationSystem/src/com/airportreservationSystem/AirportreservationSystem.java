package com.airportreservationSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
public class AirportreservationSystem {
	private static Scanner scanner = new Scanner(System.in);
    private static int loggedInUserId = -1;
    private static boolean isAdmin = false;
     
    public static void main(String[] args) {
    	System.out.println("Welcome To Airlinereservation");
        while (true) {
            if (loggedInUserId == -1) {
                showLoginMenu();
            } else {
                if (isAdmin) {
                    showAdminMenu();
                } else {
                    showUserMenu();
                }
            }
        }
    }

    private static void showLoginMenu() {
        System.out.println("Choose the choice:");

        System.out.println("1. Register");
        System.out.println("2. Login");
        System.out.println("3. Exit");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                register();
                break;
            case 2:
                login();
                break;
            case 3:
            	logout();
                break;
            default:
                System.out.println("Invalid choice. Try again.");
        }
    }

    private static void showUserMenu() {
    	System.out.println("Choose The Choice:");
        System.out.println("1. View Flights");
        System.out.println("2. Book Flight");
        System.out.println("3. View My Reservations");
        System.out.println("4. Update User Details");
        System.out.println("5. Logout");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                viewFlights();
                break;
            case 2:
                bookFlight();
                break;
            case 3:
                viewReservations();
                break;
            case 4:
                updateUser();
                break;
            case 5:
                logout();
                break;
            default:
                System.out.println("Invalid choice. Try again.");
        }
    }

    private static void showAdminMenu() {
    	System.out.println("Choose The Choice:");
        System.out.println("1. View Flights");
        System.out.println("2. Add Flight");
        System.out.println("3. Edit Flight");
        System.out.println("4. Delete Flight");
        System.out.println("5. Add Airport");
        System.out.println("6. Edit Airport");
        System.out.println("7. Delete Airport");
        System.out.println("8. View Airports");
        System.out.println("9. View All Users");
        System.out.println("10. Logout");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                viewFlights();
                break;
            case 2:
                addFlight();
                break;
            case 3:
                editFlight();
                break;
            case 4:
                deleteFlight();
                break;
            case 5:
                addAirport();
                break;
            case 6:
                editAirport();
                break;
            case 7:
                deleteAirport();
                break;
            case 8:
                viewAirports();
                break;
            case 9:
                viewAllUsers();
                break;
            case 10:
                logout();
                break;
            default:
                System.out.println("Invalid choice. Try again.");
        }
    }

    private static void register() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO users (username, password) VALUES (?, ?)");
            statement.setString(1, username);
            statement.setString(2, password);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Registration successful.");
            } else {
                System.out.println("Error during registration.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT id, is_admin FROM users WHERE username = ? AND password = ?");
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                loggedInUserId = resultSet.getInt("id");
                isAdmin = resultSet.getBoolean("is_admin");
                System.out.println("Login successful.");
            } else {
                System.out.println("Invalid username or password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void logout() {
        loggedInUserId = -1;
        isAdmin = false;
        System.out.println("Logged out successfully.");
    }

    private static void viewFlights() {
        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM flights");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println("Flight ID: " + resultSet.getInt("id"));
                System.out.println("Flight Number: " + resultSet.getString("flight_number"));
                System.out.println("Origin Airport ID: " + resultSet.getInt("origin_airport_id"));
                System.out.println("Destination Airport ID: " + resultSet.getInt("destination_airport_id"));
                System.out.println("Departure Time: " + resultSet.getTimestamp("departure_time"));
                System.out.println("Arrival Time: " + resultSet.getTimestamp("arrival_time"));
                System.out.println("----------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void bookFlight() {
        System.out.print("Enter flight ID to book: ");
        int flightId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO reservations (user_id, flight_id) VALUES (?, ?)");
            statement.setInt(1, loggedInUserId);
            statement.setInt(2, flightId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Flight booked successfully.");
            } else {
                System.out.println("Error booking flight.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewReservations() {
        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM reservations r JOIN flights f ON r.flight_id = f.id WHERE r.user_id = ?");
            statement.setInt(1, loggedInUserId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println("Reservation ID: " + resultSet.getInt("id"));
                System.out.println("Flight Number: " + resultSet.getString("flight_number"));
                System.out.println("Origin Airport ID: " + resultSet.getInt("origin_airport_id"));
                System.out.println("Destination Airport ID: " + resultSet.getInt("destination_airport_id"));
                System.out.println("Departure Time: " + resultSet.getTimestamp("departure_time"));
                System.out.println("Arrival Time: " + resultSet.getTimestamp("arrival_time"));
                System.out.println("----------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addFlight() {
        System.out.print("Enter flight number: ");
        String flightNumber = scanner.nextLine();
        System.out.print("Enter origin airport ID: ");
        int originAirportId = scanner.nextInt();
        System.out.print("Enter destination airport ID: ");
        int destinationAirportId = scanner.nextInt();
        System.out.print("Enter departure time (yyyy-MM-dd HH:mm:ss): ");
        scanner.nextLine(); // consume newline
        String departureTime = scanner.nextLine();
        System.out.print("Enter arrival time (yyyy-MM-dd HH:mm:ss): ");
        String arrivalTime = scanner.nextLine();

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO flights (flight_number, origin_airport_id, destination_airport_id, departure_time, arrival_time) VALUES (?, ?, ?, ?, ?)");
            statement.setString(1, flightNumber);
            statement.setInt(2, originAirportId);
            statement.setInt(3, destinationAirportId);
            statement.setTimestamp(4, Timestamp.valueOf(departureTime));
            statement.setTimestamp(5, Timestamp.valueOf(arrivalTime));
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Flight added successfully.");
            } else {
                System.out.println("Error adding flight.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void editFlight() {
        System.out.print("Enter flight ID to edit: ");
        int flightId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new flight number: ");
        String flightNumber = scanner.nextLine();
        System.out.print("Enter new origin airport ID: ");
        int originAirportId = scanner.nextInt();
        System.out.print("Enter new destination airport ID: ");
        int destinationAirportId = scanner.nextInt();
        System.out.print("Enter new departure time (yyyy-MM-dd HH:mm:ss): ");
        scanner.nextLine(); // consume newline
        String departureTime = scanner.nextLine();
        System.out.print("Enter new arrival time (yyyy-MM-dd HH:mm:ss): ");
        String arrivalTime = scanner.nextLine();

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "UPDATE flights SET flight_number = ?, origin_airport_id = ?, destination_airport_id = ?, departure_time = ?, arrival_time = ? WHERE id = ?");
            statement.setString(1, flightNumber);
            statement.setInt(2, originAirportId);
            statement.setInt(3, destinationAirportId);
            statement.setTimestamp(4, Timestamp.valueOf(departureTime));
            statement.setTimestamp(5, Timestamp.valueOf(arrivalTime));
            statement.setInt(6, flightId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Flight updated successfully.");
            } else {
                System.out.println("Error updating flight.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteFlight() {
        System.out.print("Enter flight ID to delete: ");
        int flightId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM flights WHERE id = ?");
            statement.setInt(1, flightId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Flight deleted successfully.");
            } else {
                System.out.println("Error deleting flight.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addAirport() {
        System.out.print("Enter airport name: ");
        String name = scanner.nextLine();
        System.out.print("Enter airport code: ");
        String code = scanner.nextLine();

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO airports (name, code) VALUES (?, ?)");
            statement.setString(1, name);
            statement.setString(2, code);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Airport added successfully.");
            } else {
                System.out.println("Error adding airport.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void editAirport() {
        System.out.print("Enter airport ID to edit: ");
        int airportId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new airport name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new airport code: ");
        String code = scanner.nextLine();

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "UPDATE airports SET name = ?, code = ? WHERE id = ?");
            statement.setString(1, name);
            statement.setString(2, code);
            statement.setInt(3, airportId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Airport updated successfully.");
            } else {
                System.out.println("Error updating airport.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteAirport() {
        System.out.print("Enter airport ID to delete: ");
        int airportId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM airports WHERE id = ?");
            statement.setInt(1, airportId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Airport deleted successfully.");
            } else {
                System.out.println("Error deleting airport.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAirports() {
        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM airports");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println("Airport ID: " + resultSet.getInt("id"));
                System.out.println("Airport Name: " + resultSet.getString("name"));
                System.out.println("Airport Code: " + resultSet.getString("code"));
                System.out.println("----------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllUsers() {
        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM users");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println("User ID: " + resultSet.getInt("id"));
                System.out.println("Username: " + resultSet.getString("username"));
                System.out.println("Is Admin: " + resultSet.getBoolean("is_admin"));
                System.out.println("----------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateUser() {
        System.out.print("Enter new username: ");
        String username = scanner.nextLine();
        System.out.print("Enter new password: ");
        String password = scanner.nextLine();

        Connection connection = DatabaseConnection.getConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "UPDATE users SET username = ?, password = ? WHERE id = ?");
            statement.setString(1, username);
            statement.setString(2, password);
            statement.setInt(3, loggedInUserId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User details updated successfully.");
            } else {
                System.out.println("Error updating user details.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}